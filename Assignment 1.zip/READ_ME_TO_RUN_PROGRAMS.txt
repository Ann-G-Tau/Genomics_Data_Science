All programs are written in C++ language.
To execute a program, first create an executable by g++ <programname> -o <executablename>.
e.g. g++ question1a.cpp -o myprogram
Then, run the program with the executable and commandline arguments.
e.g. ./myProgram <inputFile> <outputFile> // IMPORTANT: please add "./" before the executable to run